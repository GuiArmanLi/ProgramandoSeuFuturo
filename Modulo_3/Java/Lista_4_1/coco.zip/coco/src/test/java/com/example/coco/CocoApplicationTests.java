package com.example.coco;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CocoApplicationTests {

	@Test
	void contextLoads() {
	}

}
