package com.example.mercadinho;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MercadinhoApplicationTests {

	@Test
	void contextLoads() {
	}

}
